// function searchShop() {
//             const shopName = document.getElementById('shopSearch').value.toLowerCase();

//             // Example shop URLs
//             const shops = {
//                 "coffee shop": "new1.html",
//                 "book store": "1.html",
//                 "grocery store": "grocery-store.html",
//             };

//             if (shops[shopName]) {
//                 window.location.href = shops[shopName];
//             } else {
//                 alert("Shop not found!");
//             }
//         }


function searchShop() {
    const shopName = document.getElementById('shopInput').value.toLowerCase();

    // Example shop URLs
    const shops = {
        "coffee shop": "new1.html",
        "book store": "1.html",
        "grocery store": "grocery-store.html",
    };

    if (shops[shopName]) {
        window.location.href = shops[shopName];
    } else {
        alert("Shop not found!");
    }
}
