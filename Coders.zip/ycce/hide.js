// Check if the user is already signed in on page load
document.addEventListener("DOMContentLoaded", function() {
    const isLoggedIn = localStorage.getItem("isLoggedIn");

    const signInBtn = document.getElementById("signInBtn");
    const signUpBtn = document.getElementById("signUpBtn");
    const signOutBtn = document.getElementById("signOutBtn");

    if (isLoggedIn === "true") {
        signInBtn.style.display = "none";
        signUpBtn.style.display = "none";
        signOutBtn.style.display = "inline-block";
    }

    // Handle sign out button click
    signOutBtn.addEventListener("click", function() {
        localStorage.setItem("isLoggedIn", "false");
        signInBtn.style.display = "inline-block";
        signUpBtn.style.display = "inline-block";
        signOutBtn.style.display = "none";
    });
});

// Mock sign in function (you should replace this with actual sign in logic)
function signIn() {
    // Perform your sign-in logic here (e.g., validate user credentials)
    // If successful, set isLoggedIn to true in local storage
    localStorage.setItem("isLoggedIn", "true");

    // Redirect to home page after successful sign-in
    window.location.href = "home.html";
}

// Example of attaching the signIn function to the Sign In button
document.getElementById("signInBtn").addEventListener("click", signIn);
