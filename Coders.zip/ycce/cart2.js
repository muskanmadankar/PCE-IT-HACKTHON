// Adding event listeners to "Add to cart" buttons
document.querySelectorAll('.add-to-cart').forEach(button => {
    button.addEventListener('click', event => {
        event.preventDefault();

        // Get the product details from the button's data attributes
        const productName = button.getAttribute('data-name');
        const productPrice = button.getAttribute('data-price');

        // Create a new object to store product details
        const product = {
            name: productName,
            price: productPrice
        };

        // Retrieve the existing cart from localStorage or create a new one
        let cart = JSON.parse(localStorage.getItem('cart')) || [];

        // Add the product to the cart
        cart.push(product);

        // Save the updated cart back to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));

        // Optionally, give feedback to the user
        alert(`${productName} has been added to your cart!`);
    });
});
