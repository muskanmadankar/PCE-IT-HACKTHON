document.addEventListener("DOMContentLoaded", () => {
    const signUpButton = document.getElementById('signUpOverlay');
    const signInButton = document.getElementById('signInOverlay');
    const container = document.querySelector('.container');

    // Toggle between Sign In and Sign Up forms
    signUpButton.addEventListener('click', () => {
        container.classList.add('right-panel-active');
    });

    signInButton.addEventListener('click', () => {
        container.classList.remove('right-panel-active');
    });

    // Sign Up form submission
    const signUpForm = document.querySelector('.sign-up-container form');
    signUpForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const name = signUpForm.querySelector('input[type="text"]').value;
        const email = signUpForm.querySelector('input[type="email"]').value;
        const password = signUpForm.querySelector('input[type="password"]').value;

        // Store sign up data in local storage
        localStorage.setItem('name', name);
        localStorage.setItem('email', email);
        localStorage.setItem('password', password);

        alert('Sign up successful!');
    });

    // Sign In form submission
    const signInForm = document.querySelector('.sign-in-container form');
    signInForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = signInForm.querySelector('input[type="email"]').value;
        const password = signInForm.querySelector('input[type="password"]').value;

        // Retrieve sign up data from local storage
        const storedEmail = localStorage.getItem('email');
        const storedPassword = localStorage.getItem('password');

        // Check if the entered data matches the stored data
        if (email === storedEmail && password === storedPassword) {
            alert('Sign in successful!');
        } else {
            alert('Invalid email or password!');
        }
    });
});
