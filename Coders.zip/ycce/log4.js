// Sign In form submission
const signInForm = document.querySelector('.sign-in-container form');
signInForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = signInForm.querySelector('input[type="email"]').value;
    const password = signInForm.querySelector('input[type="password"]').value;

    // Retrieve sign up data from local storage
    const storedEmail = localStorage.getItem('email');
    const storedPassword = localStorage.getItem('password');

    // Check if the entered email and password match the stored data
    if (email === storedEmail && password === storedPassword) {
        alert('Sign in successful!');
        // Redirect to the homepage or another page after successful login
        window.location.href = 'new1.html'; // Change 'home.html' to your desired page

        // After redirect, update the buttons
        localStorage.setItem('isLoggedIn', 'true');
    } else {
        alert('Invalid email or password');
    }
});

// To update the login button based on the user's login status
document.addEventListener("DOMContentLoaded", () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn');

    if (isLoggedIn === 'true') {
        document.querySelector('.nav-btn').innerText = 'Sign Out';
        document.querySelector('.nav-btn').addEventListener('click', () => {
            localStorage.removeItem('isLoggedIn');
            window.location.reload(); // Refresh the page to update the UI
        });

        // Hide the Sign Up button
        const signUpButton = document.querySelector('.right-content a:nth-child(2)');
        if (signUpButton) {
            signUpButton.style.display = 'none';
        }
    }
});
