// Adding event listeners to "Add to cart" buttons
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productName = this.getAttribute('data-name');
                const productPrice = this.getAttribute('data-price');

                // Get cart from localStorage or create a new one
                let cart = JSON.parse(localStorage.getItem('cart')) || [];

                // Add the product to the cart
                cart.push({ name: productName, price: productPrice });

                // Save the cart back to localStorage
                localStorage.setItem('cart', JSON.stringify(cart));

                alert(`${productName} has been added to your cart!`);
            });
        });