let menu = document.querySelector("#menu-icon");
let navlist = document.querySelector(".navlist");

menu.onclick = () => {
    menu.classList.toggle("bx-x");
    navlist.classList.toggle("active");
}

// for header transparent to black

let header = document.querySelector('header');

window.addEventListener('scroll' , () =>{
         header.classList.toggle('shadow' , window.scrollY > 0);
});



// seach button

let search = document.querySelector('.search-box');

document.querySelector('#search-icon').onclick = () => {
    search.classList.toggle('active');
}


